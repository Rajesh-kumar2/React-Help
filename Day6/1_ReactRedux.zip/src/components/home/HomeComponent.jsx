import React from 'react';

const HomeComponent = ()=> (
    <div>
        <h1>Home Component</h1>
        <h4 className="text-info">This is a simple, React Redux Application</h4>
    </div>
);

export default HomeComponent;