import 'react';
import 'react-dom';

import 'prop-types';
import 'react-router-dom';
import 'react-loadable';
import 'react-bootstrap';
import 'redux';
import 'react-redux';

import 'jquery';
import 'bootstrap/dist/js/bootstrap';
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap/dist/css/bootstrap-theme.css';